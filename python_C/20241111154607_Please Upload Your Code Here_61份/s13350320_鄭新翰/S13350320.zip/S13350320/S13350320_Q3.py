test_input='1234'
print(sum(map(int,list(test_input))))