#3
test_input = 1234
sum_of_digits = sum(int(digit) for digit in str(test_input))
print(sum_of_digits) 
