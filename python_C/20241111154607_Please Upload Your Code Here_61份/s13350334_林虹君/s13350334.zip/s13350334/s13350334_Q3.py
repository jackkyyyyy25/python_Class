test_input=1234
a=test_input
d=[int(i) for i in str(a)]
d=sum(d)
print(d)