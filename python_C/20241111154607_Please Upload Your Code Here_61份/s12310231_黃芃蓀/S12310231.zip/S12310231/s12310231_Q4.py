test_input="racecar"
if test_input==''.join(reversed(test_input)):
    print("Palindrome")
else:
    print("Not Palindrome")
