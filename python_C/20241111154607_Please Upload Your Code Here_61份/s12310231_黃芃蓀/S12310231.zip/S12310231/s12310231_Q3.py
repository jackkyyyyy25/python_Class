test_input=1234
sum_digits=sum(map(int,str(test_input)))
print(sum_digits)

