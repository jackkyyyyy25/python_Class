#midterm#3
test_input="1234"
sum_of_numbers=(sum(int(digit)for digit in test_input))
print(sum_of_numbers)