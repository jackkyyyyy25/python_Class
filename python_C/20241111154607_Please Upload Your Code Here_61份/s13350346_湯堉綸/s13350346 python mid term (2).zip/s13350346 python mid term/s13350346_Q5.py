#midterm#5
def findmissingnum(nums5):
    answer=((nums5[0]+nums5[-1])//2)
    return answer
test_input=[3,0,1]
print(findmissingnum(test_input))
