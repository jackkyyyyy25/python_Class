test_input='racecar'
if test_input=='palindrome':
    print('Palindrome')
else:
    print('Not Palindrome')
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        
