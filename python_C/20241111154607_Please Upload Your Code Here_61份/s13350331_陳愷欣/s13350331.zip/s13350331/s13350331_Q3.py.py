test_input=1234
test_input = abs(test_input)
print( sum(int(digit) for digit in str(test_input)))
