test_input=[3,0,1]
nums = test_input
a=len(nums)
total=(a*(a+1))//2
array_sum=sum(nums)
print(total-array_sum)
