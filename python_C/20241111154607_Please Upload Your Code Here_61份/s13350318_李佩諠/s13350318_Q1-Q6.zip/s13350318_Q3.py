test_input=1234
a=sum(int(i)for i in str(test_input))
print(a)
