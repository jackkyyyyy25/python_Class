test_input = "上海自來水來自海上"
if test_input == test_input[::-1]:
    print("Palindrome")
else:
    print("Not Palindrome")