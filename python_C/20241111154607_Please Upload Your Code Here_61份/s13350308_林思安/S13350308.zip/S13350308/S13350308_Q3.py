test_input = "1234"
a = sum(int(num)for num in test_input)
print(a)
