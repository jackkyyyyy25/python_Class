test_input = [3,0,1,2,6,4]
n = len(test_input)
a = sum(test_input)
b = n * (n + 1) / 2
c = b - a
print(int(c))
