test_input = [3,0,1]
test_input.sort()
a = []
for i in range(max(test_input)+1):
    if i != test_input[i] :
        print(i)
        break

