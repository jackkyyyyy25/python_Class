def solve2(n):
    n= list(map(int,list(str(n))))
    return sum(n)


test_input = 1234
print(solve2(test_input))

