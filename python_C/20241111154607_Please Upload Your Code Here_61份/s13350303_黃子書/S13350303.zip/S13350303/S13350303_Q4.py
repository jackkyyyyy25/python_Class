tsst_input = "racecar"
ans = ""
for ch in tsst_input:
    ans =  ch + ans

if  tsst_input == ans:
    print("Palindrome")
else:
    print("Not Palindrome")
