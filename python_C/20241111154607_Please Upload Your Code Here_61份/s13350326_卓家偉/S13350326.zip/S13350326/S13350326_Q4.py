test_input="racecar"
if test_input==test_input:
    print("palindrome")
else:
    print("Not palindrome")