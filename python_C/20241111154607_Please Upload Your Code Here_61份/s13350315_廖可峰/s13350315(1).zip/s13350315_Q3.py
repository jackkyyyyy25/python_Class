test_input = 1234
a = [int(digit) for digit in str(test_input)]
print(sum(a))  
