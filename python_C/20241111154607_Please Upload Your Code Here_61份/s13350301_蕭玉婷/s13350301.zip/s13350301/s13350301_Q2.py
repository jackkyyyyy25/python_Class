test_input = [100, 4, 200, 1, 3, 2]
test_input.sort()
print(test_input)

