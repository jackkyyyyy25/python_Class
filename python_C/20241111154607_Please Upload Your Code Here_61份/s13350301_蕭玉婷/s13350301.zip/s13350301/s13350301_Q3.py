test_input = 1234
a = list(str(test_input))
digit_sum = sum(int(digit) for digit in a)
print(digit_sum )
