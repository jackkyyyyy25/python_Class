test_input = "racecar"
if test_input == test_input[::-1]:
    print("palindrome")
else:
    print("Not palindrome")
