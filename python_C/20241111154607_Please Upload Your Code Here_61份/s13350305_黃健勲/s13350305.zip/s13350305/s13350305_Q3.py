test_input=1234
alist=[]
for i in str(test_input):
    alist.append(int(i))
print(sum(alist))
    


    
