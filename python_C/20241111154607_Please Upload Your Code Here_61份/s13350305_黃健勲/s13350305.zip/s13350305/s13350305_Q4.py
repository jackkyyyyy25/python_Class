test_input="racecar"
n=len(test_input)-1
if test_input[0]==test_input[n]:
    print("Palindrome")
else:
    print("Not Palindrome")
