test_input = 1234
ans = str(test_input)
sum_of_digits = sum(int(digit) for digit in str(test_input))
print("test_input = 1234")
print(sum_of_digits)
