test_input = "1234"
num = sum(int(digit) for digit in test_input)
print(num)
