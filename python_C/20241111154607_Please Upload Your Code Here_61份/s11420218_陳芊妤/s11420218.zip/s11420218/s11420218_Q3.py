test_input = 1234
sum = 0

for digit in str(test_input):
   sum += int(digit)
print(sum)