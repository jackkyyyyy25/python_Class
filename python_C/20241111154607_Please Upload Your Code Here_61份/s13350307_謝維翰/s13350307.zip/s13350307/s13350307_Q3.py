test_input = 1234
b = str(test_input)
a = 0
for i in b:
    a += int(i)
print(a)