test_input = "racecar"
reversev = test_input[::-1]
if test_input == reversev:
    print("Palindrome")
else:
    print("Not Palindrome")