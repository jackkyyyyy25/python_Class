test_input = 1234
str1 = (" ").join(test_input)
print(str1)
