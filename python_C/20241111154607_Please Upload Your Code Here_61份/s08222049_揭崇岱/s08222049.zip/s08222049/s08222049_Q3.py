test_input=1234
output = sum(int(digit) for digit in str(test_input))
print(output) 
