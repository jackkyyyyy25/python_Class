test_input = 1234
digits = sum(int(digit) for digit in str(abs(test_input)))
print(digits)