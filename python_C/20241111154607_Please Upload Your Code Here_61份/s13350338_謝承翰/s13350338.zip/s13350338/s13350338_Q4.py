test_input = "racecar"

if (test_input == test_input[::-1]):
    print("Palindrome")
else:
    print("Not Palindrome")