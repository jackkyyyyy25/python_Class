test_input = 1234
sum = 0 
for i in str(test_input):
    sum +=int(i)
print(sum)